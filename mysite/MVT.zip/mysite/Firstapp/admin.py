from django.contrib import admin
from Firstapp.models import Submit

# Register your models here.
admin.site.register(Submit)